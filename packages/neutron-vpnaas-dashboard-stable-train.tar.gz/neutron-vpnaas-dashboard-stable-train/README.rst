========================
Neutron VPNaaS Dashboard
========================

OpenStack Dashboard panels for Neutron VPNaaS

* Documentation: https://docs.openstack.org/neutron-vpnaas-dashboard/latest/
* Source: https://opendev.org/openstack/neutron-vpnaas-dashboard
* Bugs: https://bugs.launchpad.net/neutron-vpnaas-dashboard
* Release Notes: https://docs.openstack.org/releasenotes/neutron-vpnaas-dashboard/

Team and repository tags
------------------------

.. image:: https://governance.openstack.org/tc/badges/neutron-vpnaas-dashboard.svg
    :target: https://governance.openstack.org/tc/reference/tags/index.html
