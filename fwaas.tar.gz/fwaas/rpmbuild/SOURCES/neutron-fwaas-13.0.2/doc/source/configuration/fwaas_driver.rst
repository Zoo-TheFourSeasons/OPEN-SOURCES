================
fwaas_driver.ini
================

.. show-options::
   :config-file: etc/oslo-config-generator/fwaas_driver.ini
