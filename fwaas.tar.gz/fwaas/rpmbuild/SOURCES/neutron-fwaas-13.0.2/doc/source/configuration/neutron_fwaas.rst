==================
neutron_fwaas.conf
==================

.. show-options::
   :config-file: etc/oslo-config-generator/neutron_fwaas.conf
